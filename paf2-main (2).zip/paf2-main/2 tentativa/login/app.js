var btnSignin = document.querySelector("#signin");
var btnSignup = document.querySelector("#signup");
var body = document.querySelector("body");

btnSignin.addEventListener("click", function () {
    body.className = "sign-in-js"; 
});

btnSignup.addEventListener("click", function () {
    body.className = "sign-up-js";
});

// Função para verificar o login
function verificarLogin(email, password) {
    fetch('users.json')
        .then(response => response.json())
        .then(users => {
            const usuario = users.find(user => user.email === email && user.password === password);
            if (usuario) {
                alert('Login bem-sucedido!');
                // Aqui você pode redirecionar o usuário ou realizar outra ação
            } else {
                alert('Email ou senha incorretos!');
            }
        })
        .catch(error => console.error('Erro ao carregar os usuários:', error));
}

// Adicionando o evento de clique no botão de login
document.querySelector('.btn-second').addEventListener('click', (e) => {
    e.preventDefault(); // Evitar o envio do formulário
    const email = document.querySelector('input[type="email"]').value;
    const password = document.querySelector('input[type="password"]').value;
    verificarLogin(email, password);
});
