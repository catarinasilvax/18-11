<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Inclua o autoload do Composer ou o arquivo do PHPMailer
require 'vendor/autoload.php';

// Verifica se os dados foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtém e sanitiza os dados do formulário
    $nome = htmlspecialchars(strip_tags($_POST['nome']));
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $mensagem = htmlspecialchars(strip_tags($_POST['mensagem']));

    // Validações básicas (opcional, mas recomendável)
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "E-mail inválido.";
        exit;
    }
    if (empty($nome) || empty($mensagem)) {
        echo "Por favor, preencha todos os campos.";
        exit;
    }

    // Cria uma instância do PHPMailer
    $mail = new PHPMailer(true);

    try {
        // Ative o modo debug para diagnósticos (desative em produção)
        $mail->SMTPDebug = 0; // Pode usar 2 para depuração mais detalhada
        
        // Configurações do servidor SMTP
        $mail->isSMTP();                                          // Define que o envio será via SMTP
        $mail->Host = 'smtp.gmail.com';                           // Define o servidor SMTP (Gmail)
        $mail->SMTPAuth = true;                                   // Ativa autenticação SMTP
        $mail->Username = 'catarinasilva470@gmail.com';           // Seu e-mail (usuário SMTP)
        $mail->Password = 'iosz pkrd fjkq ygli';                 // Sua senha de aplicativo (não a senha principal)
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;       // Criptografia TLS
        $mail->Port = 587;                                       // Porta do servidor SMTP

        // Remetente e destinatário
        $mail->setFrom('catarinasilva470@gmail.com', 'Contato EasySchool'); // Seu e-mail e nome
        $mail->addAddress('easyschoollisboa@gmail.com', 'EasySchool');     // E-mail do destinatário
        $mail->addReplyTo($email, $nome);                                  // E-mail para resposta

        // Conteúdo do e-mail
        $mail->isHTML(false);                                      // Define o formato do e-mail como texto simples
        $mail->Subject = 'Mensagem do formulário de contato';
        $mail->Body    = "Nome: " . $nome . "\n" .
                         "E-mail: " . $email . "\n" .
                         "Mensagem: \n" . $mensagem;

        // Envia o e-mail
        $mail->send();
        echo 'Mensagem enviada com sucesso!';
    } catch (Exception $e) {
        echo "Erro ao enviar a mensagem. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
